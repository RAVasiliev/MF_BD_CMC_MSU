# HW_1_CMC_MSU
ДЗ #1, которое включает в себя задания по Python, NumPy, Pandas и визуализации 
